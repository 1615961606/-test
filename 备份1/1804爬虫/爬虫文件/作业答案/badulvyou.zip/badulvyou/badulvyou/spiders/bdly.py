# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from badulvyou.items import BadulvyouItem


class BdlySpider(CrawlSpider):
    name = 'bdly'
    allowed_domains = ['baidu.com']
    #https://lvyou.baidu.com/scene/t-all_s-all_a-all_l-all?rn=12&pn=0
    #https://lvyou.baidu.com/scene/t-all_s-all_a-all_l-all?rn=12&pn=12
    start_urls = ['https://lvyou.baidu.com/scene/t-all_s-all_a-all_l-all?rn=12&pn=0']

    rules = (
        Rule(LinkExtractor(
            allow=r'.*?rn=12&pn=\d+',
            restrict_xpaths='//span[@class="pagelist"]'
        ),
            follow=True),
        #https://lvyou.baidu.com/tianjin/
        Rule(
            LinkExtractor(
                allow='https://lvyou.baidu.com/[a-z]+/$',
                restrict_xpaths='//ul[@class="filter-result"]'
            ),
            callback='parse_detail_data'
        )
    )

    def parse_detail_data(self,response):
        print(response.status)
        #提取数据
        item = BadulvyouItem()
        # 标题
        item['title'] = response.xpath('//a[@class="clearfix"]/text()').extract_first()
        # 分值
        item['score'] = response.xpath('//span[@class="star-new"]/text()').extrcat_first()
        # 评论数
        item['commentNums'] = response.xpath('//a[@class="remark-count"]/text()').re('\d+')[0]
        # 简介
        item['content'] = ','.join(response.xpath('//p[@class="main-desc-p"]//text()').extrcat()).replace(' ','').replace('\n','')
        # 建议
        item['suggent'] = ','.join(response.xpath('//div[@class="main-intro"]//span/text()').extract()).replace(' ','').replace('\n','')

        # 图片
        imageLink = response.urljoin(response.xpath('//a[@class="pic-more more-pic-tip clearfix"]/@href').extract_first())

        item['images'] = []


        #提取评论信息
        remark_list = response.xpath('//div[@class="remark-list"]/div')

        comment_list = []

        for remark in remark_list:
            #取出每一条评论的信息
            remark_dict = {}
            remark_dict['name'] = remark.xpath('.//a[@class="ri-uname"]/text()').extract_frist()
            remark_dict['publishTime'] = remark.xpath('.//div[@class="ri-time"]/text()').extract_first()
            remark_dict['content'] = ','.join(remark.xpath('.//div[@class="ri-remarktxt"]/text()').extract()).replace(' ','').replace('\n','')
            comment_list.append(remark_dict)
        # 评论列表
        item['commentsList'] = comment_list

        yield scrapy.Request()





